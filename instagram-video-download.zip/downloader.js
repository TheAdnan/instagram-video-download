function download(){
	return src = document.querySelectorAll('video')[0].src;
}

download();