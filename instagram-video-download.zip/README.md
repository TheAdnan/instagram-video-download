### **instagram video download** - *A WebExtension for downloading instagram videos*
![logo](https://github.com/TheAdnan/instagram-video-download/blob/master/icons/insta-48.png)
##### Download instagram videos easily 

#### About

Add-on is still under development

#### Other

You can download my other add-on, instagram-download, for downloading instagram photos here: [Instagram photo downloader](https://addons.mozilla.org/en-US/firefox/addon/ig-photo-downloader/).


[![License: MPL 2.0](https://img.shields.io/badge/License-MPL%202.0-brightgreen.svg)](https://opensource.org/licenses/MPL-2.0)
This extension is under MPL-2.0 License.

